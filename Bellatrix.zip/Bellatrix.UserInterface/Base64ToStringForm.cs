﻿using System;
using System.Windows.Forms;

namespace Bellatrix.UserInterface
{
    public partial class Base64ToStringForm : Form
    {
        public Base64ToStringForm()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
