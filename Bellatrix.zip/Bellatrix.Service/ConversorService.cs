﻿using Newtonsoft.Json;
using System.Security.Cryptography;
using System.Text;
using System.Xml.Linq;

namespace Bellatrix.Service
{
    public class ConversorService
    {
        public const string ENCODE_TO_BASE_64 = "-b64=";
        public const string DECODE_FROM_BASE_64 = "-str=";
        public const string ENCODE_TO_HASH = "-hash=";
        public const string FORMAT_XML = "-fxml=";
        public const string FORMAT_JSON = "-fjson=";

        /// <summary>
        /// Converter string em Base64
        /// </summary>
        /// <param name="str">string a ser condificado</param>
        /// <returns></returns>
        public string EncodeToBase64(string str)
        {
            byte[] textoAsBytes = Encoding.ASCII.GetBytes(str);
            string resultado = System.Convert.ToBase64String(textoAsBytes);
            return resultado;
        }

        /// <summary>
        /// Converter Base64 em string
        /// </summary>
        /// <param name="base64">string a ser decondificado</param>
        /// <returns></returns>
        public string DecodeFrom64(string base64)
        {
            byte[] dadosAsBytes = System.Convert.FromBase64String(base64);
            string resultado = ASCIIEncoding.ASCII.GetString(dadosAsBytes);
            return resultado;
        }

        /// <summary>
        /// Converter string em Hash
        /// </summary>
        /// <param name="str">string a ser codificada</param>
        /// <returns></returns>
        public string EncodeToHash(string str)
        {
            MD5 md5 = MD5.Create();
            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(str);
            byte[] hash = md5.ComputeHash(inputBytes);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hash.Length; i++)
            {
                sb.Append(hash[i].ToString("x2"));
            }
            return sb.ToString();
        }

        /// <summary>
        /// Formatar XML
        /// </summary>
        /// <param name="xml">XML a ser formatado</param>
        /// <returns></returns>
        public string FormatXml(string xml)
        {
            XDocument doc = XDocument.Parse(xml);
            return doc.ToString();
        }

        /// <summary>
        /// Formatar JSON
        /// </summary>
        /// <param name="json">Json a ser formatado</param>
        /// <returns></returns>
        public string FormatJson(string json)
        {
            return JsonConvert.SerializeObject(json, Formatting.Indented);
        }
    }
}
