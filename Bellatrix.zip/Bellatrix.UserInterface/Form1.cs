﻿using Bellatrix.Service;
using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bellatrix.UserInterface
{
    public partial class BELLATRIX : Form
    {
        Task taskCursor = null;
        private Form activeForms = null;
        CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

        public BELLATRIX()
        {
            InitializeComponent();
            CustomizeDesign();
        }

        #region [CONFIG]

        private void CustomizeDesign()
        {
            this.panelMenuEnvironment.Visible = false;
            this.panelMenuFind.Visible = false;
            this.panelMenuMonitoring.Visible = false;
            this.panelMenuMyTime.Visible = false;
            this.panelMenuTextTools.Visible = false;
        }
        private void HideSubMenu()
        {
            if (this.panelMenuEnvironment.Visible)
                this.panelMenuEnvironment.Visible = !this.panelMenuEnvironment.Visible;

            if (this.panelMenuFind.Visible)
                this.panelMenuFind.Visible = !this.panelMenuFind.Visible;

            if (this.panelMenuMonitoring.Visible)
                this.panelMenuMonitoring.Visible = !this.panelMenuMonitoring.Visible;

            if (this.panelMenuMyTime.Visible)
                this.panelMenuMyTime.Visible = !this.panelMenuMyTime.Visible;

            if (this.panelMenuTextTools.Visible)
                this.panelMenuTextTools.Visible = !this.panelMenuTextTools.Visible;
        }

        private void ShowSubMenu(Panel subMenu)
        {
            if(!subMenu.Visible)
            {
                HideSubMenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }

        private void OpenChildForm(Form childForm)
        {
            if (activeForms != null)
                activeForms.Close();
            activeForms = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            this.panelShadowForm.Controls.Add(childForm);
            childForm.BringToFront();
            childForm.Show();
            HideSubMenu();
        }

        #endregion

        #region [MENU]
        private void btnMenuTextTools_Click(object sender, EventArgs e) => ShowSubMenu(this.panelMenuTextTools);

        private void btnMenuFind_Click(object sender, EventArgs e) => ShowSubMenu(this.panelMenuFind);

        private void btnMenuMyTime_Click(object sender, EventArgs e) => ShowSubMenu(this.panelMenuMyTime);

        private void btnEnvironment_Click(object sender, EventArgs e) => ShowSubMenu(this.panelMenuEnvironment);

        private void btnMonitoring_Click(object sender, EventArgs e) => ShowSubMenu(this.panelMenuMonitoring);
        #endregion

        #region [SUB-MENU]

        private void btnStringToBase_Click(object sender, EventArgs e) => OpenChildForm(new StringToBase64Form());

        private void btnBaseToString_Click(object sender, EventArgs e) => OpenChildForm(new Base64ToStringForm());

        private void btnXmlFormater_Click(object sender, EventArgs e) => OpenChildForm(new XmlFormaterForm());

        private void btnJsonFormater_Click(object sender, EventArgs e) => OpenChildForm(new JsonFormatForm());

        private void btnFindByName_Click(object sender, EventArgs e)
        {

        }

        private void btnFindByContent_Click(object sender, EventArgs e)
        {

        }

        private void btnRegisterTime_Click(object sender, EventArgs e)
        {

        }

        private void btnListTasks_Click(object sender, EventArgs e)
        {

        }

        private void btnStartPrograms_Click(object sender, EventArgs e)
        {

        }

        private void btnTestNetwork_Click(object sender, EventArgs e)
        {

        }

        private void btnAppMonitoring_Click(object sender, EventArgs e)
        {

        }

        #endregion
        
        private void label1_DoubleClick(object sender, EventArgs e)
        {
            MessageBoxButtons buttons = MessageBoxButtons.YesNoCancel;
            var result = MessageBox.Show("Active Cursor", "Alert", buttons);

            if (result == DialogResult.Yes)
            {
                taskCursor = new Task(() => LoopCursor(cancellationTokenSource.Token));
                taskCursor.Start();
            }
            if (result == DialogResult.No)
            {
                cancellationTokenSource.Cancel();
            }
        }

        private void LoopCursor(CancellationToken token)
        {
            while (true)
            {
                if (token.IsCancellationRequested)
                {
                    MessageBox.Show("Active Cursor - Finallized");
                    throw new TaskCanceledException();
                }

                Task.Delay(5000).Wait();
                CursorService.SetCursorPos(200, 200);
                Task.Delay(5000).Wait();
                CursorService.SetCursorPos(200, 400);
            }
        }

        
    }
}
