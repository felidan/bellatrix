﻿using System;
using System.Windows.Forms;

namespace Bellatrix.UserInterface
{
    public partial class JsonFormatForm : Form
    {
        public JsonFormatForm()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
