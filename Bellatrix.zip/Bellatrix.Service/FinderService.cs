﻿using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Bellatrix.Service
{
    public class FinderService
    {
        public const string FIND_FILE_NAME = "-findfile=";
        public const string FIND_BY_CONTENT = "-findcontent=";

        /// <summary>
        /// Busca arquivos que contenham "value" no NOME
        /// </summary>
        /// <param name="path">Caminho da procura</param>
        /// <param name="value">Valor procurado</param>
        /// <returns></returns>
        public List<string> FindByNameFile(string path, string value)
        {
            List<string> result = new List<string>();
            if (Directory.Exists(path))
            {
                string[] files = Directory.GetFiles(path) ?? new string[0];

                files
                    .Where(x => x.Contains(value))?
                    .ToList()
                    .ForEach(x 
                        => result.Add(x));
            }
            return result;
        }

        /// <summary>
        /// Busca arquivos que contenham "value" no CONTEUDO
        /// </summary>
        /// <param name="path">Caminho do arquivo</param>
        /// <param name="value">Valor procurado</param>
        /// <returns></returns>
        public List<int> FindByContentFile(string path, string value)
        {
            List<int> result = new List<int>();
            int lineNumber = 1;

            if (Directory.Exists(path))
            {
                using (var stream = new StreamReader(path))
                {
                    while (!stream.EndOfStream)
                    {
                        var line = stream.ReadLine();

                        if (line.ToLower().Contains(value.ToLower()))
                            result.Add(lineNumber);
                        lineNumber++;
                    }
                }
            }

            return result;
        }
    }
}