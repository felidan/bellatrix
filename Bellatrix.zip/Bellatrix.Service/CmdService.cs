﻿using System.Diagnostics;

namespace Bellatrix.Service
{
    public class CmdService
    {
        public const string LIST_TASK = "-lt";
        public const string OPEN_PROG= "-op=";
        
        /// <summary>
        /// Listar tarefas em execução no Windows
        /// </summary>
        /// <returns></returns>
        public string ListTasks()
        {
            string output = "";
            Process cmd = new Process();
            cmd.StartInfo.FileName = "cmd.exe";
            cmd.StartInfo.RedirectStandardInput = true;
            cmd.StartInfo.RedirectStandardOutput = true;
            cmd.StartInfo.CreateNoWindow = true;
            cmd.StartInfo.UseShellExecute = false;
            cmd.Start();

            cmd.StandardInput.WriteLine("tasklist");
            cmd.StandardInput.Flush();
            cmd.StandardInput.Close();

            output = cmd.StandardOutput.ReadToEnd();

            return output;
        }

        /// <summary>
        /// Executar via CMD um programa no Windows
        /// </summary>
        /// <param name="path">Caminho do programa a ser aberto</param>
        public void OpenProgram(string path)
        {
            Process cmd = new Process();
            cmd.StartInfo.FileName = "cmd.exe";
            cmd.StartInfo.RedirectStandardInput = true;
            cmd.StartInfo.RedirectStandardOutput = true;
            cmd.StartInfo.CreateNoWindow = true;
            cmd.StartInfo.UseShellExecute = false;
            cmd.Start();

            cmd.StandardInput.WriteLine(path);
            cmd.StandardInput.Flush();
            cmd.StandardInput.Close();
        }
    }
}
