﻿namespace Bellatrix.Service
{
    public class MonitoringService
    {
    }
}
