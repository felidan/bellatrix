﻿namespace Bellatrix.UserInterface
{
    partial class BELLATRIX
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BELLATRIX));
            this.panelLogo = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnMenuTextTools = new System.Windows.Forms.Button();
            this.panelMenuTextTools = new System.Windows.Forms.Panel();
            this.btnJsonFormater = new System.Windows.Forms.Button();
            this.btnXmlFormater = new System.Windows.Forms.Button();
            this.btnStringToBase = new System.Windows.Forms.Button();
            this.btnBaseToString = new System.Windows.Forms.Button();
            this.panelSideMenu = new System.Windows.Forms.Panel();
            this.panelMenuMonitoring = new System.Windows.Forms.Panel();
            this.btnAppMonitoring = new System.Windows.Forms.Button();
            this.btnTestNetwork = new System.Windows.Forms.Button();
            this.btnMonitoring = new System.Windows.Forms.Button();
            this.panelMenuEnvironment = new System.Windows.Forms.Panel();
            this.btnStartPrograms = new System.Windows.Forms.Button();
            this.btnListTasks = new System.Windows.Forms.Button();
            this.btnEnvironment = new System.Windows.Forms.Button();
            this.panelMenuMyTime = new System.Windows.Forms.Panel();
            this.btnRegisterTime = new System.Windows.Forms.Button();
            this.btnMenuMyTime = new System.Windows.Forms.Button();
            this.panelMenuFind = new System.Windows.Forms.Panel();
            this.btnFindByContent = new System.Windows.Forms.Button();
            this.btnFindByName = new System.Windows.Forms.Button();
            this.btnMenuFind = new System.Windows.Forms.Button();
            this.panelShadowForm = new System.Windows.Forms.Panel();
            this.panelChildForm = new System.Windows.Forms.Panel();
            this.panelFooter = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panelLogo.SuspendLayout();
            this.panelMenuTextTools.SuspendLayout();
            this.panelSideMenu.SuspendLayout();
            this.panelMenuMonitoring.SuspendLayout();
            this.panelMenuEnvironment.SuspendLayout();
            this.panelMenuMyTime.SuspendLayout();
            this.panelMenuFind.SuspendLayout();
            this.panelShadowForm.SuspendLayout();
            this.panelFooter.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelLogo
            // 
            this.panelLogo.Controls.Add(this.label1);
            resources.ApplyResources(this.panelLogo, "panelLogo");
            this.panelLogo.Name = "panelLogo";
            // 
            // label1
            // 
            this.label1.CausesValidation = false;
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.Lavender;
            this.label1.Name = "label1";
            this.label1.DoubleClick += new System.EventHandler(this.label1_DoubleClick);
            // 
            // btnMenuTextTools
            // 
            resources.ApplyResources(this.btnMenuTextTools, "btnMenuTextTools");
            this.btnMenuTextTools.FlatAppearance.BorderSize = 0;
            this.btnMenuTextTools.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnMenuTextTools.Name = "btnMenuTextTools";
            this.btnMenuTextTools.UseVisualStyleBackColor = true;
            this.btnMenuTextTools.Click += new System.EventHandler(this.btnMenuTextTools_Click);
            // 
            // panelMenuTextTools
            // 
            this.panelMenuTextTools.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.panelMenuTextTools.Controls.Add(this.btnJsonFormater);
            this.panelMenuTextTools.Controls.Add(this.btnXmlFormater);
            this.panelMenuTextTools.Controls.Add(this.btnStringToBase);
            this.panelMenuTextTools.Controls.Add(this.btnBaseToString);
            resources.ApplyResources(this.panelMenuTextTools, "panelMenuTextTools");
            this.panelMenuTextTools.Name = "panelMenuTextTools";
            // 
            // btnJsonFormater
            // 
            resources.ApplyResources(this.btnJsonFormater, "btnJsonFormater");
            this.btnJsonFormater.FlatAppearance.BorderSize = 0;
            this.btnJsonFormater.ForeColor = System.Drawing.Color.LightGray;
            this.btnJsonFormater.Name = "btnJsonFormater";
            this.btnJsonFormater.UseVisualStyleBackColor = true;
            this.btnJsonFormater.Click += new System.EventHandler(this.btnJsonFormater_Click);
            // 
            // btnXmlFormater
            // 
            resources.ApplyResources(this.btnXmlFormater, "btnXmlFormater");
            this.btnXmlFormater.FlatAppearance.BorderSize = 0;
            this.btnXmlFormater.ForeColor = System.Drawing.Color.LightGray;
            this.btnXmlFormater.Name = "btnXmlFormater";
            this.btnXmlFormater.UseVisualStyleBackColor = true;
            this.btnXmlFormater.Click += new System.EventHandler(this.btnXmlFormater_Click);
            // 
            // btnStringToBase
            // 
            resources.ApplyResources(this.btnStringToBase, "btnStringToBase");
            this.btnStringToBase.FlatAppearance.BorderSize = 0;
            this.btnStringToBase.ForeColor = System.Drawing.Color.LightGray;
            this.btnStringToBase.Name = "btnStringToBase";
            this.btnStringToBase.UseVisualStyleBackColor = true;
            this.btnStringToBase.Click += new System.EventHandler(this.btnStringToBase_Click);
            // 
            // btnBaseToString
            // 
            resources.ApplyResources(this.btnBaseToString, "btnBaseToString");
            this.btnBaseToString.FlatAppearance.BorderSize = 0;
            this.btnBaseToString.ForeColor = System.Drawing.Color.LightGray;
            this.btnBaseToString.Name = "btnBaseToString";
            this.btnBaseToString.UseVisualStyleBackColor = true;
            this.btnBaseToString.Click += new System.EventHandler(this.btnBaseToString_Click);
            // 
            // panelSideMenu
            // 
            resources.ApplyResources(this.panelSideMenu, "panelSideMenu");
            this.panelSideMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.panelSideMenu.Controls.Add(this.panelMenuMonitoring);
            this.panelSideMenu.Controls.Add(this.btnMonitoring);
            this.panelSideMenu.Controls.Add(this.panelMenuEnvironment);
            this.panelSideMenu.Controls.Add(this.btnEnvironment);
            this.panelSideMenu.Controls.Add(this.panelMenuMyTime);
            this.panelSideMenu.Controls.Add(this.btnMenuMyTime);
            this.panelSideMenu.Controls.Add(this.panelMenuFind);
            this.panelSideMenu.Controls.Add(this.btnMenuFind);
            this.panelSideMenu.Controls.Add(this.panelMenuTextTools);
            this.panelSideMenu.Controls.Add(this.btnMenuTextTools);
            this.panelSideMenu.Controls.Add(this.panelLogo);
            this.panelSideMenu.Name = "panelSideMenu";
            // 
            // panelMenuMonitoring
            // 
            this.panelMenuMonitoring.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.panelMenuMonitoring.Controls.Add(this.btnAppMonitoring);
            this.panelMenuMonitoring.Controls.Add(this.btnTestNetwork);
            resources.ApplyResources(this.panelMenuMonitoring, "panelMenuMonitoring");
            this.panelMenuMonitoring.Name = "panelMenuMonitoring";
            // 
            // btnAppMonitoring
            // 
            this.btnAppMonitoring.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            resources.ApplyResources(this.btnAppMonitoring, "btnAppMonitoring");
            this.btnAppMonitoring.FlatAppearance.BorderSize = 0;
            this.btnAppMonitoring.ForeColor = System.Drawing.Color.LightGray;
            this.btnAppMonitoring.Name = "btnAppMonitoring";
            this.btnAppMonitoring.UseVisualStyleBackColor = false;
            this.btnAppMonitoring.Click += new System.EventHandler(this.btnAppMonitoring_Click);
            // 
            // btnTestNetwork
            // 
            this.btnTestNetwork.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            resources.ApplyResources(this.btnTestNetwork, "btnTestNetwork");
            this.btnTestNetwork.FlatAppearance.BorderSize = 0;
            this.btnTestNetwork.ForeColor = System.Drawing.Color.LightGray;
            this.btnTestNetwork.Name = "btnTestNetwork";
            this.btnTestNetwork.UseVisualStyleBackColor = false;
            this.btnTestNetwork.Click += new System.EventHandler(this.btnTestNetwork_Click);
            // 
            // btnMonitoring
            // 
            resources.ApplyResources(this.btnMonitoring, "btnMonitoring");
            this.btnMonitoring.FlatAppearance.BorderSize = 0;
            this.btnMonitoring.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnMonitoring.Name = "btnMonitoring";
            this.btnMonitoring.UseVisualStyleBackColor = true;
            this.btnMonitoring.Click += new System.EventHandler(this.btnMonitoring_Click);
            // 
            // panelMenuEnvironment
            // 
            this.panelMenuEnvironment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.panelMenuEnvironment.Controls.Add(this.btnStartPrograms);
            this.panelMenuEnvironment.Controls.Add(this.btnListTasks);
            resources.ApplyResources(this.panelMenuEnvironment, "panelMenuEnvironment");
            this.panelMenuEnvironment.Name = "panelMenuEnvironment";
            // 
            // btnStartPrograms
            // 
            this.btnStartPrograms.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            resources.ApplyResources(this.btnStartPrograms, "btnStartPrograms");
            this.btnStartPrograms.FlatAppearance.BorderSize = 0;
            this.btnStartPrograms.ForeColor = System.Drawing.Color.LightGray;
            this.btnStartPrograms.Name = "btnStartPrograms";
            this.btnStartPrograms.UseVisualStyleBackColor = false;
            this.btnStartPrograms.Click += new System.EventHandler(this.btnStartPrograms_Click);
            // 
            // btnListTasks
            // 
            this.btnListTasks.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            resources.ApplyResources(this.btnListTasks, "btnListTasks");
            this.btnListTasks.FlatAppearance.BorderSize = 0;
            this.btnListTasks.ForeColor = System.Drawing.Color.LightGray;
            this.btnListTasks.Name = "btnListTasks";
            this.btnListTasks.UseVisualStyleBackColor = false;
            this.btnListTasks.Click += new System.EventHandler(this.btnListTasks_Click);
            // 
            // btnEnvironment
            // 
            resources.ApplyResources(this.btnEnvironment, "btnEnvironment");
            this.btnEnvironment.FlatAppearance.BorderSize = 0;
            this.btnEnvironment.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnEnvironment.Name = "btnEnvironment";
            this.btnEnvironment.UseVisualStyleBackColor = true;
            this.btnEnvironment.Click += new System.EventHandler(this.btnEnvironment_Click);
            // 
            // panelMenuMyTime
            // 
            this.panelMenuMyTime.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.panelMenuMyTime.Controls.Add(this.btnRegisterTime);
            resources.ApplyResources(this.panelMenuMyTime, "panelMenuMyTime");
            this.panelMenuMyTime.Name = "panelMenuMyTime";
            // 
            // btnRegisterTime
            // 
            this.btnRegisterTime.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            resources.ApplyResources(this.btnRegisterTime, "btnRegisterTime");
            this.btnRegisterTime.FlatAppearance.BorderSize = 0;
            this.btnRegisterTime.ForeColor = System.Drawing.Color.LightGray;
            this.btnRegisterTime.Name = "btnRegisterTime";
            this.btnRegisterTime.UseVisualStyleBackColor = false;
            this.btnRegisterTime.Click += new System.EventHandler(this.btnRegisterTime_Click);
            // 
            // btnMenuMyTime
            // 
            resources.ApplyResources(this.btnMenuMyTime, "btnMenuMyTime");
            this.btnMenuMyTime.FlatAppearance.BorderSize = 0;
            this.btnMenuMyTime.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnMenuMyTime.Name = "btnMenuMyTime";
            this.btnMenuMyTime.UseVisualStyleBackColor = true;
            this.btnMenuMyTime.Click += new System.EventHandler(this.btnMenuMyTime_Click);
            // 
            // panelMenuFind
            // 
            this.panelMenuFind.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.panelMenuFind.Controls.Add(this.btnFindByContent);
            this.panelMenuFind.Controls.Add(this.btnFindByName);
            resources.ApplyResources(this.panelMenuFind, "panelMenuFind");
            this.panelMenuFind.Name = "panelMenuFind";
            this.panelMenuFind.TabStop = true;
            // 
            // btnFindByContent
            // 
            this.btnFindByContent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            resources.ApplyResources(this.btnFindByContent, "btnFindByContent");
            this.btnFindByContent.FlatAppearance.BorderSize = 0;
            this.btnFindByContent.ForeColor = System.Drawing.Color.LightGray;
            this.btnFindByContent.Name = "btnFindByContent";
            this.btnFindByContent.UseVisualStyleBackColor = false;
            this.btnFindByContent.Click += new System.EventHandler(this.btnFindByContent_Click);
            // 
            // btnFindByName
            // 
            this.btnFindByName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            resources.ApplyResources(this.btnFindByName, "btnFindByName");
            this.btnFindByName.FlatAppearance.BorderSize = 0;
            this.btnFindByName.ForeColor = System.Drawing.Color.LightGray;
            this.btnFindByName.Name = "btnFindByName";
            this.btnFindByName.UseVisualStyleBackColor = false;
            this.btnFindByName.Click += new System.EventHandler(this.btnFindByName_Click);
            // 
            // btnMenuFind
            // 
            resources.ApplyResources(this.btnMenuFind, "btnMenuFind");
            this.btnMenuFind.FlatAppearance.BorderSize = 0;
            this.btnMenuFind.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnMenuFind.Name = "btnMenuFind";
            this.btnMenuFind.UseVisualStyleBackColor = true;
            this.btnMenuFind.Click += new System.EventHandler(this.btnMenuFind_Click);
            // 
            // panelShadowForm
            // 
            this.panelShadowForm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.panelShadowForm.Controls.Add(this.panelChildForm);
            resources.ApplyResources(this.panelShadowForm, "panelShadowForm");
            this.panelShadowForm.Name = "panelShadowForm";
            // 
            // panelChildForm
            // 
            resources.ApplyResources(this.panelChildForm, "panelChildForm");
            this.panelChildForm.Name = "panelChildForm";
            // 
            // panelFooter
            // 
            this.panelFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.panelFooter.Controls.Add(this.textBox1);
            resources.ApplyResources(this.panelFooter, "panelFooter");
            this.panelFooter.Name = "panelFooter";
            // 
            // textBox1
            // 
            resources.ApplyResources(this.textBox1, "textBox1");
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.ForeColor = System.Drawing.Color.White;
            this.textBox1.Name = "textBox1";
            // 
            // BELLATRIX
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelShadowForm);
            this.Controls.Add(this.panelFooter);
            this.Controls.Add(this.panelSideMenu);
            this.Name = "BELLATRIX";
            this.Opacity = 0.98D;
            this.panelLogo.ResumeLayout(false);
            this.panelMenuTextTools.ResumeLayout(false);
            this.panelSideMenu.ResumeLayout(false);
            this.panelMenuMonitoring.ResumeLayout(false);
            this.panelMenuEnvironment.ResumeLayout(false);
            this.panelMenuMyTime.ResumeLayout(false);
            this.panelMenuFind.ResumeLayout(false);
            this.panelShadowForm.ResumeLayout(false);
            this.panelFooter.ResumeLayout(false);
            this.panelFooter.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.Button btnMenuTextTools;
        private System.Windows.Forms.Panel panelMenuTextTools;
        private System.Windows.Forms.Button btnJsonFormater;
        private System.Windows.Forms.Button btnXmlFormater;
        private System.Windows.Forms.Button btnStringToBase;
        private System.Windows.Forms.Button btnBaseToString;
        private System.Windows.Forms.Panel panelSideMenu;
        private System.Windows.Forms.Panel panelMenuFind;
        private System.Windows.Forms.Button btnFindByContent;
        private System.Windows.Forms.Button btnFindByName;
        private System.Windows.Forms.Button btnMenuFind;
        private System.Windows.Forms.Panel panelMenuMyTime;
        private System.Windows.Forms.Button btnRegisterTime;
        private System.Windows.Forms.Button btnMenuMyTime;
        private System.Windows.Forms.Panel panelMenuEnvironment;
        private System.Windows.Forms.Button btnStartPrograms;
        private System.Windows.Forms.Button btnListTasks;
        private System.Windows.Forms.Button btnEnvironment;
        private System.Windows.Forms.Button btnMonitoring;
        private System.Windows.Forms.Panel panelMenuMonitoring;
        private System.Windows.Forms.Button btnAppMonitoring;
        private System.Windows.Forms.Button btnTestNetwork;
        private System.Windows.Forms.Panel panelShadowForm;
        private System.Windows.Forms.Panel panelFooter;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panelChildForm;
        private System.Windows.Forms.Label label1;
    }
}

