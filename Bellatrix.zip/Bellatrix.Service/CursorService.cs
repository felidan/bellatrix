﻿using System.Runtime.InteropServices;

namespace Bellatrix.Service
{
    public static class CursorService
    {
        public const string SET_CURSOR_POS = "-param=";

        /// <summary>
        /// Mover cursor nas coordenadas X e Y
        /// </summary>
        /// <param name="x">coordenada X</param>
        /// <param name="y">coordenada Y</param>
        [DllImport("user32.dll")]
        public static extern bool SetCursorPos(int x, int y);
    }
}
