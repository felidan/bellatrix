﻿using System;
using System.Windows.Forms;

namespace Bellatrix.UserInterface
{
    public partial class XmlFormaterForm : Form
    {
        public XmlFormaterForm()
        {
            InitializeComponent();
        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
