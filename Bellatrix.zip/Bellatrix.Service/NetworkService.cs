﻿using System.Net.NetworkInformation;

namespace Bellatrix.Service
{
    public class NetworkService
    {
        public const string CONNECT_TO_INTERNET = "-connint=";

        /// <summary>
        /// Verificar conexão com a URL passada
        /// </summary>
        /// <param name="url">Url a ser verificada</param>
        /// <returns></returns>
        public bool IsConnectedToInternet(string url)
        {
            Ping p = new Ping();
            try
            {
                PingReply reply = p.Send(url, 3000);
                if (reply.Status == IPStatus.Success) return true;
                else return false;
            }
            catch
            {
                return false;
            }
        }
    }
}
